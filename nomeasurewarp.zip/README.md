# Lucky Warp
Lucky Warp is a door game with kill and teleport function of each door. The goal is this project is to demonstrate the Depth Limit Search algorithm.
Note: This is the demo game, not for presentation.

![tree](https://cdn.discordapp.com/attachments/945661001196523580/947872405752262657/unknown.png)
